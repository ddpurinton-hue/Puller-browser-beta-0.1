@echo off
cd /d "%~dp0"
echo Building Puller Browser...
python -m pip install -r requirements.txt
python -m PyInstaller --noconfirm --clean --windowed --name "Puller Browser" "Puller Browser.py"
echo.
echo Finished: dist\Puller Browser\Puller Browser.exe
pause
