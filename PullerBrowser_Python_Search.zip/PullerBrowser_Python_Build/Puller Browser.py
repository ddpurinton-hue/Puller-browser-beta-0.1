import sys, os
from pathlib import Path
from PySide6.QtCore import QUrl
from search import address_or_search
from PySide6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLineEdit, QLabel
from PySide6.QtWebEngineWidgets import QWebEngineView

BASE = Path(__file__).resolve().parent
DOWNLOADS = BASE / 'downloads'
DOWNLOADS.mkdir(exist_ok=True)

class PullerBrowser(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Puller Browser')
        self.resize(1280, 820)
        self.setStyleSheet('''
            QMainWindow,QWidget{background:#07152d;color:#eaf2ff}
            QPushButton{background:#10284b;color:#eaf2ff;border:1px solid #285b93;border-radius:9px;padding:9px}
            QPushButton:hover{background:#173a67}
            QLineEdit{background:#0b1d39;color:white;border:1px solid #285b93;border-radius:12px;padding:12px;font-size:15px}
        ''')
        outer=QHBoxLayout(); central=QWidget(); central.setLayout(outer); self.setCentralWidget(central)
        side=QVBoxLayout(); title=QLabel('PULLER'); title.setStyleSheet('font-size:25px;font-weight:bold;color:#63b8ff'); side.addWidget(title)
        for text,fn in [('⌂  Home',self.home),('⌕  Search',lambda:self.address.setFocus()),('◈  Games',lambda:self.go('https://www.google.com/search?q=browser+games')),('↓  Downloads',lambda:os.startfile(DOWNLOADS)),('♻  Recycle Bin',lambda:os.startfile(BASE/'Recycle Bin')),('▣  Desktop',lambda:os.startfile(BASE/'Desktop'))]:
            b=QPushButton(text); b.clicked.connect(fn); side.addWidget(b)
        side.addStretch(); status=QLabel('● Protected\nVirus Detector'); status.setStyleSheet('color:#64e6a7;font-weight:bold'); side.addWidget(status)
        sidebar=QWidget(); sidebar.setFixedWidth(190); sidebar.setLayout(side); sidebar.setStyleSheet('background:#061127;border-right:1px solid #17375f'); outer.addWidget(sidebar)
        main=QVBoxLayout(); outer.addLayout(main)
        head=QHBoxLayout(); h=QLabel('🔷  Puller Browser'); h.setStyleSheet('font-size:28px;font-weight:bold'); head.addWidget(h); head.addStretch()
        for text,url in [('ChatGPT','https://chatgpt.com/'),('Google','https://google.com/')]:
            b=QPushButton(text); b.clicked.connect(lambda _,u=url:self.go(u)); head.addWidget(b)
        main.addLayout(head)
        nav=QHBoxLayout()
        for text,fn in [('←',lambda:self.view.back()),('→',lambda:self.view.forward()),('↻',lambda:self.view.reload())]:
            b=QPushButton(text); b.clicked.connect(fn); nav.addWidget(b)
        self.address=QLineEdit(); self.address.setPlaceholderText('Search the web or enter a website address'); self.address.returnPressed.connect(self.navigate); self.address.setClearButtonEnabled(True); nav.addWidget(self.address,1); main.addLayout(nav)
        shortcuts=QHBoxLayout()
        for text,url in [('YouTube','https://youtube.com/'),('Google','https://google.com/'),('Discord','https://discord.com/'),('Roblox','https://roblox.com/'),('Minecraft','https://minecraft.net/'),('Twitch','https://twitch.tv/'),('X','https://x.com/')]:
            b=QPushButton(text); b.clicked.connect(lambda _,u=url:self.go(u)); shortcuts.addWidget(b)
        main.addLayout(shortcuts)
        self.view=QWebEngineView(); self.view.urlChanged.connect(lambda u:self.address.setText(u.toString())); self.view.page().profile().downloadRequested.connect(self.download); main.addWidget(self.view,1)
        foot=QLabel('Fast. Simple. Everything you need in one place.     Puller Browser • DD'); foot.setStyleSheet('color:#6e91b7'); main.addWidget(foot)
        self.home()
    def home(self):
        self.view.setHtml("""<html><body style='background:#07152d;color:#eaf2ff;font-family:Segoe UI;text-align:center;padding:70px'><h1 style='font-size:48px;color:#63b8ff'>Puller Browser</h1><p style='font-size:20px;color:#9db8d7'>Fast. Simple. Everything you need in one place.</p><div style='margin:45px auto;max-width:760px;padding:25px;border:1px solid #285b93;border-radius:18px;background:#0b1d39'><h2>Quick Links</h2><p>Use a shortcut or search the web above.</p></div></body></html>""")
    def navigate(self):
        s=address_or_search(self.address.text())
        if s:
            self.go(s)
    def go(self,url): self.view.setUrl(QUrl(url))
    def download(self,item): item.setDownloadDirectory(str(DOWNLOADS)); item.accept()

app=QApplication(sys.argv); app.setApplicationName('Puller Browser'); app.setOrganizationName('DD'); w=PullerBrowser(); w.show(); sys.exit(app.exec())
