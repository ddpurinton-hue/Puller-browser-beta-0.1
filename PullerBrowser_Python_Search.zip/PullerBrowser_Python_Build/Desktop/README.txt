Local Puller Browser desktop area.
