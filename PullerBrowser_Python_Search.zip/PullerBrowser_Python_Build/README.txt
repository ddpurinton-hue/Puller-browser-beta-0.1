Puller Browser by DD

Main application: Puller Browser.py
Double-click launcher.bat to run the Python version.
Run build.bat on Windows after Python is installed to package Puller Browser.exe.
Downloads go into the downloads folder.
