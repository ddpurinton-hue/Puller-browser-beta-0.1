from urllib.parse import quote_plus

SEARCH_ENGINE = "https://www.google.com/search?q="


def address_or_search(text: str) -> str:
    text = text.strip()
    if not text:
        return ""
    # Allow common local/Internet URL forms.
    if "://" in text:
        return text
    if text.startswith(("localhost:", "127.0.0.1:")):
        return "http://" + text
    if "." in text and " " not in text:
        return "https://" + text
    return SEARCH_ENGINE + quote_plus(text)
