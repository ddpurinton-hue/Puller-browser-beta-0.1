@echo off
cd /d "%~dp0"
python "Puller Browser.py"
if errorlevel 1 pause
