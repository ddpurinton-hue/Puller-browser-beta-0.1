Local Puller Browser recycle-bin area.
